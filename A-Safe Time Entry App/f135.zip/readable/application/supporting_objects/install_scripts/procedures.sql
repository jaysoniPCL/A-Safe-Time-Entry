create or replace Procedure ASAFE_TIME_ENTRY_API as
l_json CLOB;
l_timestamp VARCHAR2(200) := TO_CHAR(SYSTIMESTAMP, 'YYYY-MM-DD"T"HH24:MI:SS.FF3TZD"+00:00"');
l_http_response utl_http.resp;
l_id varchar2(32767);
l_Person_Number varchar2(32767);
l_event_time varchar2(32767);
l_location varchar2(32767);

status_code varchar2(32767);
REASON_PHRASE   varchar2(32767);

	CURSOR data_cursor IS
        SELECT ATEAI.ID, ATEAI.CARDHOLDERID, ATEAI.EVENTTIME, ATEAI.LOCATION
        FROM ASAFE_TIME_ENTRY_API_INPUT ATEAI;

BEGIN
	UTL_HTTP.SET_WALLET('');
	
    EXECUTE IMMEDIATE 'DELETE FROM ASAFE_TIME_ENTRY_RESPONSE';
    
	apex_web_service.g_request_headers(1).name := 'Content-Type';
	apex_web_service.g_request_headers(1).value := 'application/json';
	
	FOR data_row IN data_cursor LOOP
		l_id := data_row.ID;
		l_Person_Number := data_row.CARDHOLDERID;
		l_event_time := TO_CHAR(TO_DATE(data_row.EVENTTIME, 'YYYY-MM-DD HH24:MI:SS'), 'YYYY-MM-DD"T"HH24:MI:SS".000+00:00"');
		l_location := data_row.LOCATION;
		
/*		
    dbms_output.put_line('l_id... '||l_id);
	dbms_output.put_line('l_Person_Number.. '||l_Person_Number);
	dbms_output.put_line('l_event_time... '||l_event_time);
	dbms_output.put_line('l_location... '||l_location);
	dbms_output.put_line('---------------------------------------------------------------------------------------');
*/		
	
	l_json := apex_web_service.make_rest_request(
					p_url            => 'https://fa-eueq-test-saasfaprod1.fa.ocs.oraclecloud.com/hcmWorkforceMgmtApi/resources/latest/timeEventRequests/',
					p_username       => CREDENTIALS_DETAILS.GP_USERNAME,	--'USERNAME'
					p_password       => CREDENTIALS_DETAILS.GP_PASSWORD,	--'PASSWORD'
					p_http_method    => 'POST',
					p_body           =>'{
									"requestNumber": "'||l_id||'",
									"sourceId": "HQ-Office",
									"requestTimestamp": "'||l_timestamp||'",
									"timeEvents": [{
										"eventDateTime": "'||l_event_time||'",
										"supplierDeviceEvent": "'||l_location||'",
										"reporterId": "'||l_Person_Number||'",
										"reporterIdType": "PERSON",
										"timeEventAttributes": [
											{
											"name": "PayrollTimeType",
											"value": "Regular Shifts Hours"
											}]
										}]
									}');
/*	
	dbms_output.put_line ('status_code : '||apex_web_service.g_status_code);
	dbms_output.put_line ('REASON_PHRASE : '||APEX_WEB_SERVICE.G_REASON_PHRASE);
	dbms_output.put_line ('detailed_sqlerrm : '||utl_http.get_detailed_sqlerrm);
	dbms_output.put_line('---------------------------------------------------------------------------------------');
*/

    status_code := (apex_web_service.g_status_code);
    REASON_PHRASE := (APEX_WEB_SERVICE.G_REASON_PHRASE);

    EXECUTE IMMEDIATE 
                  'INSERT INTO ASAFE_TIME_ENTRY_RESPONSE (ID,CARDHOLDERID,EVENTTIME,LOCATION,STATUS_CODE,REASON_PHRASE)
                  Values(:l_id,:l_Person_Number,:l_event_time,:l_location,:status_code,:REASON_PHRASE)'
                    USING l_id,l_Person_Number,l_event_time,l_location,status_code,REASON_PHRASE;
   
	END LOOP;
	
	apex_web_service.g_request_headers.delete();
	--EXECUTE IMMEDIATE 'DELETE FROM ASAFE_TIME_ENTRY_API_INPUT';

END	ASAFE_TIME_ENTRY_API;
/
create or replace Procedure ASAFE_TIME_ENTRY_API_COPY as
l_json CLOB;
l_timestamp VARCHAR2(200) := TO_CHAR(SYSTIMESTAMP, 'YYYY-MM-DD"T"HH24:MI:SS.FF3TZD"+00:00"');
l_http_response utl_http.resp;
l_id varchar2(32767);
l_Person_Number varchar2(32767);
l_event_time varchar2(32767);
l_location varchar2(32767);
l_response clob;

status_code varchar2(32767);
REASON_PHRASE   varchar2(32767);



	CURSOR data_cursor IS
		SELECT ATEAI.ID, ATEAI.CARDHOLDERID, ATEAI.EVENTTIME, ATEAI.LOCATION
		FROM ASAFE_TIME_ENTRY_API_INPUT_COPY	ATEAI;

BEGIN
    
	--- Calling the procedure 
	--Time_Record_CardHolderId_Report;

	UTL_HTTP.SET_WALLET('');
    
    --EXECUTE IMMEDIATE 'DELETE FROM ASAFE_TIME_ENTRY_API_INPUT_COPY';
    EXECUTE IMMEDIATE 'DELETE FROM ASAFE_TIME_ENTRY_RESPONSE_COPY';
    
	apex_web_service.g_request_headers(1).name := 'Content-Type';
	apex_web_service.g_request_headers(1).value := 'application/json';

	FOR data_row IN data_cursor LOOP
		l_id := data_row.ID;
		l_Person_Number := data_row.CARDHOLDERID;
		l_event_time := TO_CHAR(TO_DATE(data_row.EVENTTIME, 'YYYY-MM-DD HH24:MI:SS'), 'YYYY-MM-DD"T"HH24:MI:SS".000+00:00"');
        l_location := data_row.LOCATION;

 		
		--dbms_output.put_line('l_id... '||l_id);
		--dbms_output.put_line('l_Person_Number.. '||l_Person_Number);
		--dbms_output.put_line('l_event_time... '||l_event_time);
		--dbms_output.put_line('l_location... '||l_location);
		--dbms_output.put_line('---------------------------------------------------------------------------------------');


	l_json := apex_web_service.make_rest_request(
					p_url            => 'https://fa-eueq-test-saasfaprod1.fa.ocs.oraclecloud.com/hcmWorkforceMgmtApi/resources/latest/timeEventRequests/',
					p_username       => CREDENTIALS_DETAILS.GP_USERNAME,	--'USERNAME'
					p_password       => CREDENTIALS_DETAILS.GP_PASSWORD,	--'PASSWORD'
					p_http_method    => 'POST',
					p_body           =>'{
									"requestNumber": "'||l_id||'",
									"sourceId": "HQ-Office",
									"requestTimestamp": "'||l_timestamp||'",
									"timeEvents": [{
										"eventDateTime": "'||l_event_time||'",
										"supplierDeviceEvent": "'||l_location||'",
										"reporterId": "'||l_Person_Number||'",
										"reporterIdType": "PERSON",
										"timeEventAttributes": [
											{
											"name": "PayrollTimeType",
											"value": "Regular Shifts Hours"
											}]
										}]
									}');

    
    status_code := (apex_web_service.g_status_code);
    REASON_PHRASE := (APEX_WEB_SERVICE.G_REASON_PHRASE);
    
	dbms_output.put_line ('status_code : '||apex_web_service.g_status_code);
	dbms_output.put_line ('REASON_PHRASE : '||APEX_WEB_SERVICE.G_REASON_PHRASE);
	--dbms_output.put_line ('detailed_sqlerrm : '||utl_http.get_detailed_sqlerrm);
	--dbms_output.put_line('---------------------------------------------------------------------------------------');
  
    IF (status_code = 400)
    THEN
        EXECUTE IMMEDIATE 
            'INSERT INTO ASAFE_TIME_ENTRY_RESPONSE_COPY (ID,CARDHOLDERID,EVENTTIME,LOCATION,STATUS_CODE,REASON_PHRASE)
            Values(:l_id,:l_Person_Number,:l_event_time,:l_event_time,:status_code,:REASON_PHRASE)'
            USING l_id,l_Person_Number,l_event_time,l_location,status_code,REASON_PHRASE;
    END IF;
    
    
    END LOOP;
	
 /*   
    FOR idx IN (SELECT * FROM ASAFE_TIME_ENTRY_RESPONSE)
    LOOP
    
		dbms_output.put_line('ID... '||idx.ID);
		dbms_output.put_line('CARDHOLDERID.. '||idx.CARDHOLDERID);
		dbms_output.put_line('EVENTTIME... '||idx.EVENTTIME);
		dbms_output.put_line('LOCATION... '||idx.LOCATION);
		dbms_output.put_line('STATUS_CODE... '||idx.STATUS_CODE);
		dbms_output.put_line('REASON_PHRASE... '||idx.REASON_PHRASE);

	END LOOP;
*/
	--EXECUTE IMMEDIATE 'DELETE ASAFE_TIME_ENTRY_RESPONSE';
	--EXECUTE IMMEDIATE 'DELETE FROM ASAFE_TIME_ENTRY_API_INPUT';

END	ASAFE_TIME_ENTRY_API_COPY;
/
create or replace procedure Time_Record_CardHolderId_Report is
l_envelope CLOB;
l_xml XMLTYPE;
l_result VARCHAR2(32767);
l_base64 CLOB;
l_blob BLOB;
l_clob CLOB;

-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

BEGIN

UTL_HTTP.SET_WALLET('');
apex_web_service.g_request_headers.delete();


l_envelope := '<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:pub="http://xmlns.oracle.com/oxp/service/PublicReportService">
<soapenv:Header/>   
<soapenv:Body>
<pub:runReport>
<pub:reportRequest>
<pub:attributeLocale>en-US</pub:attributeLocale>            
<pub:reportAbsolutePath>/Custom/All Reports/Time Entry/Time_Record_CardHolderId_RPT.xdo</pub:reportAbsolutePath>
</pub:reportRequest>
<pub:userID>'||CREDENTIALS_DETAILS.GP_USERNAME||'</pub:userID>
<pub:password>'||CREDENTIALS_DETAILS.GP_PASSWORD||'</pub:password>   
</pub:runReport>
</soapenv:Body>
</soapenv:Envelope>';
-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

l_xml := APEX_WEB_SERVICE.MAKE_REQUEST(
P_URL => 'https://fa-eueq-test-saasfaprod1.fa.ocs.oraclecloud.com/xmlpserver/services/PublicReportService'
,P_ENVELOPE => l_envelope);

l_base64 := apex_web_service.parse_xml_clob(p_xml => l_xml,p_xpath => '//reportBytes/text()',p_ns =>'xmlns="http://xmlns.oracle.com/oxp/service/PublicReportService"');

l_clob := XX_FROM_BASE64(l_base64);
-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------



--DBMS_OUTPUT.PUT_LINE('l_base64... '||l_base64);
--DBMS_OUTPUT.PUT_LINE('l_clob... '||l_clob);


EXECUTE IMMEDIATE 'DELETE FROM xx_j11';
insert into xx_j11
values (sysdate,l_clob);


--Select UTL_RAW.CAST_TO_VARCHAR2(l_clob) from xx_j11;


-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------


EXECUTE IMMEDIATE 'DELETE FROM XX_PERSON_CARDHOLDERID_DETAILS';
EXECUTE IMMEDIATE 
                  'INSERT INTO XX_PERSON_CARDHOLDERID_DETAILS
                    SELECT t.SYS_DATE, x.*
                     FROM xx_j11 t,
                          XMLTABLE (''//G_1''
                                    PASSING xmltype(t.CLOB_DATA)
                                    COLUMNS PERSON_NUMBER  varchar2 (100) PATH ''./PERSON_NUMBER'',
											CARDHOLDERID  varchar2 (100) PATH ''./CARDHOLDERID''
                    ) x
                    WHERE t.SYS_DATE = sysdate';


-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

dbms_output.put_line ('status_code : '||apex_web_service.g_status_code);
dbms_output.put_line ('REASON_PHRASE : '||APEX_WEB_SERVICE.G_REASON_PHRASE);
dbms_output.put_line ('detailed_sqlerrm : '||utl_http.get_detailed_sqlerrm);
dbms_output.put_line('---------------------------------------------------------------------------------------');

END Time_Record_CardHolderId_Report;
/ 